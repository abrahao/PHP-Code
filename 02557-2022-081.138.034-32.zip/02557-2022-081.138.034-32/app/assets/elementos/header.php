<header>
    <nav>
        <ul>
        <li><a href="../../index.php">Home</a></li>
            <li><a href="./pessoa.php">Pessoa</a></li>
            <li><a href="./conta.php">Conta</a></li>
            <li><a href="./movimentacao.php">Movimentação</a></li>
        </ul>
    </nav>
</header>