<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>

<header>
    <nav>
        <ul>
            <li><a class="menu" href="../../index.php">Home</a></li>
            <li><a class="menu" href="../../view/pessoa.php">Pessoa</a></li>
            <li><a class="menu" href="../../view/conta.php">Conta</a></li>
            <li><a class="menu" href="../../view/movimentacao.php">Movimentação</a></li>
        </ul>
    </nav>
</header>